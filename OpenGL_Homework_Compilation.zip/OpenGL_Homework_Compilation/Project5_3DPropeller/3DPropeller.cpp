#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "Shader.h"

const GLuint WIDTH = 800, HEIGHT = 600;
const GLuint FOILMAX = 10;

int main()
{
	glfwInit();

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	glfwWindowHint(GLFW_RESIZABLE, GL_FALSE);

	GLFWwindow *window = glfwCreateWindow(WIDTH, HEIGHT, "LearnOpenGL", nullptr, nullptr);

	int screenWidth, screenHeight;
	glfwGetFramebufferSize(window, &screenWidth, &screenHeight);

	if (nullptr == window)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();

		return EXIT_FAILURE;
	}

	glfwMakeContextCurrent(window);

	glewExperimental = GL_TRUE;
	if (GLEW_OK != glewInit())
	{
		std::cout << "Failed to initialize GLEW" << std::endl;
		return EXIT_FAILURE;
	}

	glViewport(0, 0, screenWidth, screenHeight);
	glEnable(GL_DEPTH_TEST);
	glDisable(GL_CULL_FACE);
	glFrontFace(GL_CCW);

	glClearColor(0.2f, 0.3f, 0.3f, 1.0f);

	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);


	Shader ourShader("core.vertexshader", "core.fragmentshader");
	ourShader.LoadOutFile("foil_spline.out");

	// Make an airfoil with differentent Z coordinates.
	std::vector<VertexAttribute> vVertex;
	for each (VertexAttribute var in ourShader.vVertexAttribute)
	{
		vVertex.push_back(var);
	}
	std::vector<GLuint> indices;
	for (size_t foilNum = 1; foilNum <= FOILMAX; foilNum++)
	{
		std::vector<VertexAttribute> vVertexAttributeTheOtherZ = ourShader.vVertexAttribute;
		for (VertexAttribute& var : vVertexAttributeTheOtherZ)
		{
			GLfloat factor = glm::log((GLfloat)foilNum + 2.5f);
			var.x = var.x * factor;
			var.y = var.y * factor;
			var.z = var.z * 2.5f * foilNum;

			// Its color attribute
			var.r = 1.0f - (GLfloat)foilNum / FOILMAX;
			var.g = 0.9f - (GLfloat)foilNum / (2 * FOILMAX);
			var.b = 0.5f - (GLfloat)foilNum / (2 * FOILMAX);
		}
		for each (VertexAttribute var in vVertexAttributeTheOtherZ)
		{
			vVertex.push_back(var);
		}
		for (size_t ii = vVertex.size() - 1; ii > vVertex.size() - vVertexAttributeTheOtherZ.size(); ii--)
		{
			indices.push_back((GLuint)ii);
			indices.push_back((GLuint)ii - 1);
			indices.push_back((GLuint)ii - 1 - vVertexAttributeTheOtherZ.size());

			indices.push_back((GLuint)ii);
			indices.push_back((GLuint)ii - 1 - vVertexAttributeTheOtherZ.size());
			indices.push_back((GLuint)ii - vVertexAttributeTheOtherZ.size());
		}
		vVertexAttributeTheOtherZ.clear();
		vVertexAttributeTheOtherZ.shrink_to_fit();
	}

	std::vector<VertexAttribute> vHub;
	GLfloat radius = 1.0f;

	for (size_t theta = 0; theta < 360; theta += 30)
	{
		GLfloat x = radius * glm::cos(theta * 3.14f / 180);
		GLfloat y = radius * glm::sin(theta * 3.14f / 180);
		VertexAttribute hub = {x, y, 0.0f, 0.0f, 0.2f, 1.0f };
		vHub.push_back(hub);
		hub = { x, y, 30.0f, 0.0f, 0.2f, 0.8f };
		vHub.push_back(hub);
	}
	std::vector<GLuint> hubIndices;
	for (size_t i = 0; i < vHub.size() - 1; i+=2)
	{
		hubIndices.push_back(i);
		hubIndices.push_back(i + 1);
		hubIndices.push_back(i + 2);

		hubIndices.push_back(i + 2);
		hubIndices.push_back(i + 1);
		hubIndices.push_back(i + 3);
		if (i == vHub.size() - 2)
		{
			hubIndices.push_back(i);
			hubIndices.push_back(i + 1);
			hubIndices.push_back(0);

			hubIndices.push_back(0);
			hubIndices.push_back(i + 1);
			hubIndices.push_back(1);
		}
	}

	GLint modelLoc = glGetUniformLocation(ourShader.Program, "model");
	GLint viewLoc = glGetUniformLocation(ourShader.Program, "view");
	GLint projLoc = glGetUniformLocation(ourShader.Program, "projection");
	GLint colorLoc = glGetUniformLocation(ourShader.Program, "userColor");

	GLuint VAO;
	glGenVertexArrays(1, &VAO);
	glBindVertexArray(VAO);
	GLuint VBO[2];
	glGenBuffers(1, &VBO[0]);
	glBindBuffer(GL_ARRAY_BUFFER, VBO[0]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(VertexAttribute) * vVertex.size(), &vVertex.front(), GL_STATIC_DRAW);
	glGenBuffers(1, &VBO[1]);
	glBindBuffer(GL_ARRAY_BUFFER, VBO[1]);
	glBufferData(GL_ARRAY_BUFFER, sizeof(VertexAttribute) * vHub.size(), &vHub.front(), GL_STATIC_DRAW);

	GLuint EBO[2];
	glGenBuffers(1, &EBO[0]);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO[0]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(GLuint), &indices.front(), GL_STATIC_DRAW);
	glGenBuffers(1, &EBO[1]);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO[1]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, hubIndices.size() * sizeof(GLuint), &hubIndices.front(), GL_STATIC_DRAW);

	while (!glfwWindowShouldClose(window))
	{
		glfwPollEvents();

		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glUseProgram(ourShader.Program);

		glBindBuffer(GL_ARRAY_BUFFER, VBO[1]);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO[1]);
		glm::mat4 model;
		glm::mat4 view;
		glm::mat4 projection;
		glm::mat3 color = glm::mat3();
		view = glm::scale(view, glm::vec3(10.0f, 10.0f, 1.0f));
		view = glm::translate(view, glm::vec3(0.0f, 0.0f, -500.11f));
		view = glm::rotate(view, 0.0f + (GLfloat)glfwGetTime() * 0.1f, glm::vec3(1.0f, 1.0f, 0.0f));
		view = glm::rotate(view, 0.0f + (GLfloat)glfwGetTime() * 0.5f, glm::vec3(0.0f, 0.0f, 1.0f));
		projection = glm::perspective(60.0f*3.14f / 180, (GLfloat)screenWidth / (GLfloat)screenHeight, 50.0f, 1000.0f);
		//view = glm::translate(view, glm::vec3((GLfloat)screenWidth / 2, (GLfloat)screenHeight / 2, -500.11f));
		//projection = glm::ortho(0.0f, (GLfloat)screenWidth, 0.0f, (GLfloat)screenHeight, 0.1f, 1000.0f);

		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
		glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
		glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));
		glUniformMatrix3fv(colorLoc, 1, GL_FALSE, glm::value_ptr(color));

		GLuint vp = glGetAttribLocation(ourShader.Program, "position");
		glEnableVertexAttribArray(vp);
		glVertexAttribPointer(vp, 3, GL_FLOAT, GL_FALSE, sizeof(VertexAttribute), (GLvoid*)(0));

		GLuint vc = glGetAttribLocation(ourShader.Program, "color");
		glEnableVertexAttribArray(vc);
		glVertexAttribPointer(vc, 3, GL_FLOAT, GL_FALSE, sizeof(VertexAttribute), (GLvoid*)(3 * sizeof(GLfloat)));

		glEnableVertexAttribArray(vp);
		glVertexAttribPointer(vp, 3, GL_FLOAT, GL_FALSE, sizeof(VertexAttribute), (GLvoid*)(0));
		glEnableVertexAttribArray(vc);
		glVertexAttribPointer(vc, 3, GL_FLOAT, GL_FALSE, sizeof(VertexAttribute), (GLvoid*)(3 * sizeof(GLfloat)));

		glDrawElements(GL_TRIANGLES, hubIndices.size(), GL_UNSIGNED_INT, 0);

		glBindBuffer(GL_ARRAY_BUFFER, VBO[0]);
		glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO[0]);
		glEnableVertexAttribArray(vp);
		glVertexAttribPointer(vp, 3, GL_FLOAT, GL_FALSE, sizeof(VertexAttribute), (GLvoid*)(0));
		glEnableVertexAttribArray(vc);
		glVertexAttribPointer(vc, 3, GL_FLOAT, GL_FALSE, sizeof(VertexAttribute), (GLvoid*)(3 * sizeof(GLfloat)));
		
		model = glm::mat4();
		model = glm::translate(model, glm::vec3(radius, 0.0f, 0.0f));
		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
		glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);

		model = glm::mat4();
		model = glm::rotate(model, 120 * 3.14f / 180, glm::vec3(0.0f, 0.0f, 1.0f));
		model = glm::translate(model, glm::vec3(radius, 0.0f, 0.0f));
		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
		glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);

		model = glm::mat4();
		model = glm::rotate(model, 240 * 3.14f / 180, glm::vec3(0.0f, 0.0f, 1.0f));
		model = glm::translate(model, glm::vec3(radius, 0.0f, 0.0f));
		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
		glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);

		color = glm::mat3(0.0f);
		glUniformMatrix3fv(colorLoc, 1, GL_FALSE, glm::value_ptr(color));
		glDrawArrays(GL_POINTS, 0, vVertex.size());

		model = glm::mat4();
		model = glm::rotate(model, 0.0f * 3.14f / 180, glm::vec3(0.0f, 0.0f, 1.0f));
		model = glm::translate(model, glm::vec3(radius, 0.0f, 0.0f));
		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
		glDrawElements(GL_POINTS, indices.size(), GL_UNSIGNED_INT, 0);

		model = glm::mat4();
		model = glm::rotate(model, 120 * 3.14f / 180, glm::vec3(0.0f, 0.0f, 1.0f));
		model = glm::translate(model, glm::vec3(radius, 0.0f, 0.0f));
		glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
		glDrawElements(GL_POINTS, indices.size(), GL_UNSIGNED_INT, 0);



		glDisableVertexAttribArray(vp);
		glDisableVertexAttribArray(vc);

		glfwSwapBuffers(window);
	}

	glDeleteVertexArrays(1, &VAO);
	glDeleteBuffers(1, &VBO[0]);
	glDeleteBuffers(1, &EBO[0]);
	glDeleteBuffers(1, &VBO[1]);
	glDeleteBuffers(1, &EBO[1]);
	glDeleteProgram(ourShader.Program);

	glfwTerminate();

	return EXIT_SUCCESS;
}
